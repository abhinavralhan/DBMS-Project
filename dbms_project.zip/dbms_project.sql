create database s_dbms;
use s_dbms;

create table Personal_Details (

FirstName varchar(15) not null, 
MiddleName varchar(15),
LastName varchar(15) not null,
StudentContact int not null,
HouseNos varchar(15),
District varchar(15) not null,
City varchar(15) not null,
State varchar(15) not null,
ZipCode int not null,
Country varchar(20) not null,
Dob date not null, 
BloodGroup varchar(5) not null,
Gender varchar(7) not null,
EmailId varchar(50) unique,

constraint PD_K primary key (FirstName, MiddleName, LastName, Dob),

EnrollmentNos varchar(15),Foreign key(EnrollmentNos) references College_Details(EnrollmentNos),

--  Parent Details

FathersName varchar(35) not null,
Fathers_Contact int not null,
MothersName varchar(35) not null,
Mothers_Contact int not null

);

create table College_Details (

EnrollmentNos varchar(15) primary key,

ProgramPursuing varchar(10) not null, -- B.tech, M.tech, Phd
Branch varchar(10) not null, -- CSE/ ECE / BTE
BatchYear int not null
);

create table Course (

EnrollmentNos varchar(15),Foreign key(EnrollmentNos) references College_Details(EnrollmentNos),

CourseCode varchar(10) primary key,

CourseName varchar(50) unique,
Faculty varchar(30) not null,
Major bool not null,
Minor bool not null

);

create table FeeStructure(

EnrollmentNos varchar(15),Foreign key(EnrollmentNos) references College_Details(EnrollmentNos),
BillNos int primary key,

TotalFeeAmount decimal not null,
ScholarshipProgram int not null, -- 111111  75%,50%,25%

FeeDueDate datetime not null,

SecurityFine float,
LibraryFine float, -- Foreign key(TotalFine) references Library(TotalFine),
MiscellaneousDues float, -- 22222222
MessCharges float,-- Foreign key(NetAmount) references Mess(NetAmount), -- 333333333
LaundryCharges float, -- Foreign key(Charges) references Laundry(Charges),  -- 444444444

FeeToBePaid int not null -- 1*2+2+3*2+4*2
-- update FeeStructure set FeeToBePaid= 1+2+3+4
);




create table Result_Attendance(

CourseCode varchar(10),Foreign key(CourseCode) references Course(CourseCode),
EnrollmentNos varchar(15),Foreign key(EnrollmentNos) references College_Details(EnrollmentNos),

MarksObtained int not null,
GradeObtained varchar(5) not null,

Attendance float
);


create table Services(
EnrollmentNos varchar(15),Foreign key(EnrollmentNos) references College_Details(EnrollmentNos),
ServiceId int primary key
);

create table  GatePass (
ServiceId int ,Foreign key(ServiceId) references Services (ServiceId),

-- GatePass--
Gatepass_Id int primary key,

SendTo varchar(20),
s_Status boolean,
TimeIn datetime,
TimeOut datetime,
VisitTo varchar(50)
);

create table Library (
ServiceId int ,Foreign key(ServiceId) references Services (ServiceId),

-- Library--
IssueId int primary key,
BookId varchar(20),
DueDate datetime,
IssueDate datetime,
Late int,
TotalFine decimal

);

create table Mess(

ServiceId int ,Foreign key(ServiceId) references Services (ServiceId),
-- Mess--
Rebate decimal

);

create table Laundry(
ServiceId int ,Foreign key(ServiceId) references Services (ServiceId),

-- Laundrary--
LaundryNos int primary key,

Services_Taken boolean,
Charges decimal

);

create table HostelDetails (

ServiceId int ,Foreign key(ServiceId) references Services (ServiceId),
-- Hostel--

Room_No int primary key,
Warden varchar(30),
DateAllotted datetime
);


create table Feedback (

EnrollmentNos varchar(15),Foreign key(EnrollmentNos) references College_Details(EnrollmentNos),

-- Feedback--
ReqId varchar(10) primary key,

Domain varchar(150),
Complaints varchar(1000),
Feedback varchar(1500)
);

create table Project_Details(

EnrollmentNos varchar(15),Foreign key(EnrollmentNos) references College_Details(EnrollmentNos),
-- Project Details
Project_Id varchar(10) primary key,

Project_Name varchar(100),
Mentor varchar(50),
Project_Aim varchar( 150)
);

create table Placement(

CompanyName varchar(50) primary key,
AboutCompany varchar(800),
ScheduledDate datetime not null,

EligibilyCriteria varchar(50) not null

);
